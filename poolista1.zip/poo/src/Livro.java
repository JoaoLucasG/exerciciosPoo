import modelo.Pessoa;

public class Livro {
    public String nome;
    public int ano;
    private String conteudo;
    Pessoa autor;

    public Livro(String n, int a){
        this.nome = n;
        this.ano = a;
    }
    public void setConteudo(String cont){
        this.conteudo = cont;
    }
    public String getConteudo(){
        return this.conteudo;
    }
}
