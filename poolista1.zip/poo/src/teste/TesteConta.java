package teste;
import modelo.*;

public class TesteConta {
    public static void main(String[] args){
        Pessoa p1 = new Pessoa("Ricardo", "123", "456");
        ContaBancaria c1 = new ContaBancaria(1, p1);
        c1.depositarSaldo(100);
        c1.exibirSaldo();

    }
}
