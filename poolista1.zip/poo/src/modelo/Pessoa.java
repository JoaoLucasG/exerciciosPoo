package modelo;

public class Pessoa {
    private String nome;
    private String telefone;
    private String CPF;

    public Pessoa(String n, String t, String c){
        this.nome = n;
        this.telefone = t;
        this.CPF = c;
    }
    public String getNome(){
        return this.nome;
    }
    public String getTelefone(){
        return this.telefone;
    }
    public String getCPF(){
        return this.CPF;
    }



}
