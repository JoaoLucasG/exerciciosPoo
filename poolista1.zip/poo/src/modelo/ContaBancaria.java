package modelo;

public class ContaBancaria {
    private int numero;
    Pessoa titular;
    private int saldo = 0;
    static double taxaJuros = 0.5;

    public ContaBancaria(int n, Pessoa t) {
        this.numero = n;
        this.titular = t;
    }

    public int getSaldo(){
        return this.saldo;
    }
    public void exibirSaldo(){
        System.out.println(this.getSaldo());
        System.out.println(this.titular.getNome());
    }
    public int getNumero(){
        return this.numero;
    }

    public void depositarSaldo(int v){
        if (v>=0){
            this.saldo += v;
        } else System.out.println("Valor inválido");
    }

    public void sacarSaldo(int v){
        if ((v<=saldo)&&(v>0)) {
            this.saldo -= v;
        } else System.out.println("Valor inválido");

    }

    public static void alterarTaxaJuros(double novaTaxa){
        taxaJuros = novaTaxa;
    }
    public static double calcularRendimento(double saldo){
        return saldo += saldo*taxaJuros;
    }
}
