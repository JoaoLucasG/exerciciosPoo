import modelo.Pessoa;

public class Carro {
    String marca;
    private String modelo;
    private int ano;
    Pessoa proprietario;
    public String getModelo(){
        return this.modelo;
    }
    public void setModelo( String novoModelo){
        this.modelo = novoModelo;
    }
}
